@echo off
chcp 65001 > nul
py -m pip install --upgrade google-api-python-client google-auth
echo.
echo ===== DONE =====
pause
