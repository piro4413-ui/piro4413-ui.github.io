@echo off
chcp 65001 > nul
cd /d %~dp0
py play_upload.py --settings settings.txt --test --confirm
echo.
pause
