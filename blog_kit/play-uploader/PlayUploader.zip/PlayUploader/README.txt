﻿Google Play 掲載情報 一括アップロードツール
（Hiroshi Studio / 2026年11月版）

各言語の「アプリ名・簡単な説明・詳しい説明・スクショ・フィーチャーグラフィック・アイコン」を、
Google Play Developer API でまとめて登録します。
手順の詳しい説明（画像付き）は、Hiroshi Studio のブログ記事をご覧ください。

■ フォルダの中身
  1_setup.bat                    最初の1回だけ：必要な部品をインストール
  2_check.bat                    点検だけ（何も送りません）
  3_upload_test_language.bat     settings.txt の TEST_LANG の言語だけ試しに送る
  4_upload_all_languages.bat     全言語を送る
  play_upload.py                 ツール本体（Python）
  settings.txt                   設定（パッケージ名など）
  store\                         素材フォルダ（見本入り。自分の素材に差し替えて使います）
  key.json                       ← 自分で用意して置く（同梱していません）

■ 素材フォルダ（store）の形
  store\
    icon.png                     アイコン 512x512（任意）
    listing\listing.csv          文章（列：language,title,short_description,full_description）
    ja-JP\                       言語ごとのフォルダ（名前は Google Play の言語コード）
      phone_01.png ～ phone_08.png  スクショ 2～8枚（PNG または JPG）
      feature.png                フィーチャーグラフィック 1024x500（任意）
    en-US\ …

  ・CSV は Excel で編集できます。保存するときは「CSV UTF-8（コンマ区切り）」を選んでください。
  ・言語コードの例：ja-JP, en-US, es-419, pt-BR, de-DE, fr-FR, ko-KR, zh-CN, zh-TW, hi-IN, id, ar, th, vi
  ・文字数の上限：アプリ名30／簡単な説明80／詳しい説明4000
  ・スクショ：一辺320～3840px、長い辺は短い辺の2倍まで

■ 送られるもの・送られないもの
  送る：各言語の文章、スクショ（今あるものは置き換え）、フィーチャーグラフィック、
        デフォルトの言語のアイコン
  送らない：アプリ本体（AAB）、データセーフティ、コンテンツのレーティングなどの申告
  通信先：Google（androidpublisher.googleapis.com）のみ

■ 安全のために
  ・key.json はパスワードと同じです。人に渡したり、GitHub などに上げたりしないでください。
  ・途中で失敗した場合、Google Play には何も反映されません（最後にまとめて確定する仕組み）。

■ ご利用にあたって
  ・Google の画面や API の仕様は変わることがあります。動作は 2026年11月時点で確認しています。
  ・本ツールの利用によって生じた損害について、作者は責任を負いかねます。自己責任でご利用ください。
  ・個人・自社のアプリでの利用は自由です。本ツールそのものの再配布・再販売はご遠慮ください。

このツールは無料です。役に立ったら応援してもらえるとうれしいです：https://ko-fi.com/hiroshistudio

Hiroshi Studio  hiroshistudio.games@gmail.com
