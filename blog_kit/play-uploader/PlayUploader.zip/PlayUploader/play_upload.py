"""
Google Play 掲載情報 一括アップロードツール（Hiroshi Studio）

ストア素材フォルダ（例：BatchRedact_store）を読み込み、
全言語の「アプリ名・簡単な説明・詳しい説明・スクショ・フィーチャーグラフィック」を
Google Play Developer API でまとめて登録します。

フォルダの形（compose_store.py が作る形と同じ）:
  <素材フォルダ>/
    icon.png                (512x512、任意)
    listing/listing.csv     (language,title,short_description,full_description)
    ja-JP/phone_01.png ... phone_08.png（PNG または JPG）、feature.png（1024x500、任意）
    en-US/...
    ...

使い方:
  python play_upload.py --package com.hiroshistudio.batchredact --key key.json --assets BatchRedact_store --dry-run
  python play_upload.py --package com.hiroshistudio.batchredact --key key.json --assets BatchRedact_store
"""
import argparse
import csv
import glob
import os
import sys
import time

LIMITS = {"title": 30, "shortDescription": 80, "fullDescription": 4000}
PHONE_SIZE_RANGE = (320, 3840)


def log(msg):
    print(msg, flush=True)


def read_listings(assets):
    files = glob.glob(os.path.join(assets, "listing", "*.csv"))
    if not files:
        sys.exit(f"[エラー] {assets}/listing/ に CSV が見つかりません。設定(settings.txt)の ASSETS と、素材フォルダの名前が合っているか確認してください")
    rows = []
    with open(files[0], encoding="utf-8-sig", newline="") as fh:
        for r in csv.DictReader(fh):
            lang = (r.get("language") or r.get("play_language") or "").strip()
            if not lang:
                continue
            rows.append({
                "language": lang,
                "title": r["title"].strip(),
                "shortDescription": r["short_description"].strip(),
                "fullDescription": r["full_description"].strip(),
            })
    return rows


IMG_EXT = (".png", ".jpg", ".jpeg")


def find(folder, stem):
    """stem で始まる画像（png/jpg）を名前順で返す"""
    out = []
    for f in sorted(os.listdir(folder)) if os.path.isdir(folder) else []:
        if f.lower().startswith(stem) and f.lower().endswith(IMG_EXT):
            out.append(os.path.join(folder, f))
    return out


def first(folder, names):
    for n in names:
        for f in find(folder, n):
            return f
    return None


def mime(path):
    return "image/png" if path.lower().endswith(".png") else "image/jpeg"


def jpeg_size(path):
    with open(path, "rb") as f:
        data = f.read()
    i = 2
    while i < len(data) - 9:
        if data[i] != 0xFF:
            i += 1
            continue
        marker = data[i + 1]
        if marker in (0xC0, 0xC1, 0xC2):
            h = int.from_bytes(data[i + 5:i + 7], "big")
            w = int.from_bytes(data[i + 7:i + 9], "big")
            return w, h
        i += 2 + int.from_bytes(data[i + 2:i + 4], "big")
    return None


def image_size(path):
    if not path.lower().endswith(".png"):
        return jpeg_size(path)
    return png_size(path)


def png_size(path):
    with open(path, "rb") as f:
        head = f.read(24)
    if head[:8] != b"\x89PNG\r\n\x1a\n":
        return None
    return int.from_bytes(head[16:20], "big"), int.from_bytes(head[20:24], "big")


def check(rows, assets):
    """送る前の点検。問題があれば一覧を返す。"""
    problems = []
    for r in rows:
        lang = r["language"]
        for k, lim in LIMITS.items():
            if not r[k]:
                problems.append(f"{lang}: {k} が空です")
            elif len(r[k]) > lim:
                problems.append(f"{lang}: {k} が{len(r[k])}文字（上限{lim}）")
        folder = os.path.join(assets, lang)
        phones = find(folder, "phone_")
        if not 2 <= len(phones) <= 8:
            problems.append(f"{lang}: スクショは2〜8枚必要（今は{len(phones)}枚）")
        for p in phones:
            s = image_size(p)
            if not s or not all(PHONE_SIZE_RANGE[0] <= v <= PHONE_SIZE_RANGE[1] for v in s) or max(s) > 2 * min(s):
                problems.append(f"{lang}: {os.path.basename(p)} のサイズが規定外 {s}")
        fg = first(folder, ["feature"])
        if fg and image_size(fg) != (1024, 500):
            problems.append(f"{lang}: フィーチャーグラフィックが1024x500ではありません")
    icon = first(assets, ["icon"])
    if icon and image_size(icon) != (512, 512):
        problems.append(f"{os.path.basename(icon)} が512x512ではありません")
    return problems


def retry(fn, what, tries=4):
    for i in range(tries):
        try:
            return fn()
        except Exception as e:  # network hiccups / 5xx / rate limits
            status = getattr(getattr(e, "resp", None), "status", None)
            if status in (400, 401, 403, 404) or i == tries - 1:
                raise
            wait = 5 * (i + 1)
            log(f"    …{what} を再試行します（{wait}秒後）: {e}")
            time.sleep(wait)


def explain(e):
    text = str(e)
    status = getattr(getattr(e, "resp", None), "status", None)
    if status == 401 or "invalid_grant" in text:
        return "鍵ファイル(JSON)が正しくないか、期限切れです。"
    if status == 403:
        return ("権限がありません。Play Console の［ユーザーと権限］で、サービスアカウントのメールアドレスに"
                "このアプリの『ストアの掲載情報の管理』権限を付けたか確認してください。"
                "Google Cloud で『Google Play Android Developer API』を有効にしたかも確認してください。")
    if status == 404:
        return "パッケージ名が違うか、Play Console にまだアプリが作られていません。"
    if "changesNotSentForReview" in text and "must be set" in text:
        return "このアプリは『公開の管理』がオンです。--not-for-review を付けて実行し、Play Console から審査に送ってください。"
    return text


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # Windows のコマンド画面で文字化けしないように
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="Google Play 掲載情報 一括アップロード")
    ap.add_argument("--package", required=True, help="例: com.hiroshistudio.batchredact")
    ap.add_argument("--key", help="サービスアカウントの鍵ファイル(JSON)")
    ap.add_argument("--assets", required=True, help="ストア素材フォルダ")
    ap.add_argument("--only", help="一部の言語だけ送る。例: ja-JP,en-US")
    ap.add_argument("--text-only", action="store_true", help="文章だけ送る（画像は送らない）")
    ap.add_argument("--icon-lang", default="ja-JP", help="アイコンを登録する言語（Play Console のデフォルトの言語）")
    ap.add_argument("--not-for-review", action="store_true", help="『公開の管理』がオンのアプリ用")
    ap.add_argument("--dry-run", action="store_true", help="点検だけして、何も送らない")
    ap.add_argument("--confirm", action="store_true", help="送る前に確認する")
    ap.add_argument("--settings", help="settings.txt から PACKAGE / KEY / ASSETS を読む")
    import shlex
    argv = sys.argv[1:]
    if "--settings" in argv:
        i = argv.index("--settings")
        path = argv[i + 1]
        try:
            conf = {}
            with open(path, encoding="utf-8-sig") as fh:
                for line in fh:
                    if "=" in line and not line.strip().startswith("#"):
                        k, v = line.split("=", 1)
                        conf[k.strip().upper()] = v.strip()
        except FileNotFoundError:
            sys.exit(f"[エラー] {path} が見つかりません")
        base = os.path.dirname(os.path.abspath(path))
        extra = ["--package", conf.get("PACKAGE", "")]
        if conf.get("KEY"):
            extra += ["--key", os.path.join(base, conf["KEY"])]
        extra += ["--assets", os.path.join(base, conf.get("ASSETS", ""))]
        if conf.get("ICON_LANG"):
            extra += ["--icon-lang", conf["ICON_LANG"]]
        if "--test" in argv:
            argv = [x for x in argv if x != "--test"]
            extra += ["--only", conf.get("TEST_LANG") or "__first__"]
        argv = extra + argv
    a = ap.parse_args(argv)

    rows = read_listings(a.assets)
    if a.only == "__first__":
        a.only = rows[0]["language"] if rows else ""
    if a.only:
        want = {x.strip() for x in a.only.split(",")}
        rows = [r for r in rows if r["language"] in want]
    log(f"対象: {len(rows)}言語  ({', '.join(r['language'] for r in rows)})")

    problems = check(rows, a.assets)
    if problems:
        log("\n[点検で問題が見つかりました。直してから実行してください]")
        for p in problems:
            log("  - " + p)
        sys.exit(1)
    log("点検OK：文字数・画像の枚数とサイズは規定内です。")

    if a.dry_run:
        for r in rows:
            n = len(find(os.path.join(a.assets, r["language"]), "phone_"))
            log(f"  {r['language']:7} 「{r['title']}」 スクショ{n}枚")
        log("\n--dry-run なので送信していません。")
        return

    if not a.key or not os.path.exists(a.key):
        sys.exit("[エラー] 鍵ファイル(key.json)が見つかりません。このフォルダに key.json を置いてください\n"
                 "（ファイル名が key.json.json になっていないかも確認してください）")

    if a.confirm:
        langs = f"{rows[0]['language']} のみ" if len(rows) == 1 else f"{len(rows)}言語"
        ans = input(f"\n{a.package} の掲載情報（{langs}）を Google Play に送ります。よろしいですか？ [y/n] ").strip().lower()
        if ans not in ("y", "yes"):
            log("中止しました。")
            return

    from google.oauth2 import service_account
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload

    try:
        creds = service_account.Credentials.from_service_account_file(
            a.key, scopes=["https://www.googleapis.com/auth/androidpublisher"])
    except Exception:
        sys.exit("[エラー] 鍵ファイルの形式が違います。Google Cloud でサービスアカウントの『鍵を追加 → JSON』で作ったファイルを指定してください")
    svc = build("androidpublisher", "v3", credentials=creds, cache_discovery=False)
    edits = svc.edits()

    try:
        edit_id = edits.insert(packageName=a.package, body={}).execute()["id"]
        log(f"編集を開始しました（{a.package}）\n")

        for i, r in enumerate(rows, 1):
            lang = r["language"]
            log(f"[{i}/{len(rows)}] {lang}")
            body = {k: r[k] for k in ("title", "shortDescription", "fullDescription")}
            body["language"] = lang
            retry(lambda: edits.listings().update(
                packageName=a.package, editId=edit_id, language=lang, body=body).execute(), "文章")
            log("    文章 OK")
            if a.text_only:
                continue
            folder = os.path.join(a.assets, lang)

            def upload(kind, path):
                retry(lambda: edits.images().upload(
                    packageName=a.package, editId=edit_id, language=lang, imageType=kind,
                    media_body=MediaFileUpload(path, mimetype=mime(path))).execute(), os.path.basename(path))

            retry(lambda: edits.images().deleteall(
                packageName=a.package, editId=edit_id, language=lang, imageType="phoneScreenshots").execute(), "古いスクショの削除")
            phones = find(folder, "phone_")
            for p in phones:
                upload("phoneScreenshots", p)
            log(f"    スクショ {len(phones)}枚 OK")

            fg = first(folder, ["feature"])
            if fg:
                retry(lambda: edits.images().deleteall(
                    packageName=a.package, editId=edit_id, language=lang, imageType="featureGraphic").execute(), "古いグラフィックの削除")
                upload("featureGraphic", fg)
                log("    フィーチャーグラフィック OK")

            icon = first(a.assets, ["icon"])
            if lang == a.icon_lang and icon:
                retry(lambda: edits.images().deleteall(
                    packageName=a.package, editId=edit_id, language=lang, imageType="icon").execute(), "古いアイコンの削除")
                upload("icon", icon)
                log("    アイコン OK")

        log("\n全言語の送信が終わりました。確定（コミット）します…")
        kw = {"changesNotSentForReview": True} if a.not_for_review else {}
        edits.commit(packageName=a.package, editId=edit_id, **kw).execute()
        log("完了しました。Play Console の［ストアの掲載情報］で内容を確認してください。")
        if a.not_for_review:
            log("※『公開の管理』がオンのため、Play Console の［公開の概要］から審査に送ってください。")
    except Exception as e:
        log("\n[失敗しました。Play には何も反映されていません]")
        log("理由: " + explain(e))
        detail = ""
        try:
            import json as _j
            detail = _j.loads(e.content.decode("utf-8"))["error"]["message"]
        except Exception:
            detail = str(e)
        log("Googleからの詳細: " + detail)
        sys.exit(1)


if __name__ == "__main__":
    main()
